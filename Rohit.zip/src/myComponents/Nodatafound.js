import React from 'react'

const Nodatafound = () => {
  return (
    <div>Nodatafound</div>
  )
}

export default Nodatafound;