
import React, { useState, useEffect } from "react";
import axios from "axios";
import { ToastContainer , toast} from "react-toastify";
import { useSelector , useDispatch } from "react-redux";
import { addTask_user } from "../Services/Services";
import { getTaskk_user } from "../store/Slices/conatctSlice";
import { setHeaderHeading } from '../store/Slices/dashboardSlice';



const add_user = {
  name: "",
  email: "",
  password: "",
  dob: "",
  contact: "",
  username:"",
};

const Contact = () => {
  const [btnToggle, setBtntoggle] = useState(false);
  const [contacts, setContacts] = useState(add_user);
  // const [tableData, settableData] = useState();
  const [Name , setName] = useState("");
  const [Email , setEmail] = useState("");
  const [Password , setPassword] = useState("");
  const [Date , setDate] = useState("");
  const [Contact , setContact] = useState("");
  const [Username , setUsername] = useState("");
  const [eyetog , seteyetog] = useState(false);
  const dispatch = useDispatch();
  var tableData = useSelector((state)=> state?.contact?.contact);
  var state = useSelector ((state)=> state?.contact);
  

  const handleContact  = (e) =>{
    const {name , value} = e.target;
    setContacts((prev)=>({...prev,[name]:value}))
  }
  console.log( "Data" ,  contacts);

  

  useEffect(()=>{
    dispatch(setHeaderHeading('Contact'));
  },[])
  const handleSubmit = () =>{

    if(Name === ""){

      toast.error("Please Enter Name", {theme:"colored"});

      

    }else if(Email === ""){
      toast.error("Please Enter Email", {theme:"colored"});
      
    }else if (Password === ""){
      toast.error("Please Enter password", {theme:"colored"});
      
    }else if(Date === ""){
      toast.error("Please Enter Date", {theme:"colored"});
      
    }else if(Contact === ""){
      toast.error("Please Enter Contact", {theme:"colored"});
      
    }else if(Username === ""){
      toast.error("Please Enter UserName", {theme:"colored"});
      
    }

    
    else{
      dispatch(addTask_user(add_user),toast.success( " Contact is Added" ,{theme:"colored"}) , setContacts('') , setName(""), setUsername(""), setContact(""),setContact(""),setDate(""),setPassword(""),setEmail(""),   setBtntoggle(false))  
    }
  
  }

  useEffect(()=>{
    dispatch(getTaskk_user())
    state.error  &&   toast.error('error')
  },[btnToggle])

  
  const toggleButton = () =>{


    // console.log("Clicked");
      let eye = document.getElementById("icon_");
      // console.log(eye, " jgswhdijs");

      eye.type === "password" ?  eye.type = "text" :  eye.type = "password";

      seteyetog(!eyetog)

  }
  return (

    <>

<div className='button_cont_new'>
            <button className='btn_accent'  onClick={() => setBtntoggle(true)}>Add contact</button>
        </div>
      <div onClick={() => setBtntoggle(false)} className='contacts_cont'>
        

        

        <ToastContainer autoClose={1000} theme="dark"/>


        <div className='table-cont'>
            <table className="Scroll_css">

              <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>D O B</th>
                <th>Contact</th>
                <th>Username</th>
              </tr>

              
             {
              tableData && tableData.map((value, index)=>{
                return(
                  <tr>
                <td>{index + 1}</td>
                <td>{value.name}</td>
                <td>{value.email}</td>               
                <td>{value.dob}</td>
                <td>{value.contact}</td>
                <td>{value.username}</td>
                
                
              </tr>
                )
              })
             } 

            </table>
        </div>



       
    </div>
    {btnToggle && btnToggle &&
            (<div className='floating_form New_form'>
            <label>Add new Contact</label>
            <input name="name" onChange={(e)=>{handleContact(e) ; setName(e.target.value)}} type="text" placeholder="Name"/>
            <input name="email" onChange={(e)=>{handleContact(e) ; setEmail(e.target.value)}}  type="email" placeholder="email"/>
            <input id="icon_" className="input_relat" name="password" onChange={(e)=>{handleContact(e) ; setPassword(e.target.value)}}  type="password" placeholder="Password"/>{eyetog ? (<i onClick={()=>{toggleButton()}} className="fa-regular fa-eye"></i>) : (<i onClick={()=>{toggleButton()}} className="fa-regular  fa-eye-slash"></i>)}
            <input name="dob" onChange={(e)=>{handleContact(e) ; setDate(e.target.value)}} type="date" placeholder="D O B "/>
            <input name="contact" onChange={(e)=>{handleContact(e) ; setContact(e.target.value)}} type="number" placeholder="Contact"/>
            <input name="username" onChange={(e)=>{handleContact(e) ; setUsername(e.target.value)}} type="type" placeholder="Username"/>
            <br/>
            <button className="btn_submit" onClick={() => {handleSubmit(); seteyetog(false)}} >Submit</button><button className="btn_cancel" onClick={() => {setBtntoggle(false);setContacts() ; setName(""); setUsername(""); setContact("");setContact("");setDate("");setPassword("");setEmail(""); seteyetog(false)  }}>Cancel</button>
          </div>)
        }
    </>
    
  )
}

export default Contact