import { createAsyncThunk } from "@reduxjs/toolkit";
import { createSlice } from "@reduxjs/toolkit";
import { toast } from "react-toastify";
import { addTask_user , getTask_user } from "../../Services/Services";
// import { addTaskk, deletetaskk, editTaskk, getTaskk } from "../../Services/Services";


const initialState = {
    contact:[],
    loading:false,
    error:false
}


export const addTaskk_user = createAsyncThunk('user/addTask_user' , async(data , {getState}) =>{
    const response = await addTask_user(data).then((res)=>{if(res){
       
    }}).catch((err)=>{toast.error("Something went wrong")})
    return response
})

export const getTaskk_user = createAsyncThunk('user/getTask_user' , async(data , {getState})=>{
    const response = await getTask_user().then((res)=>{
        const {data} = res;

        return{
            data
        },
        toast.success("Data has been added")
    }).catch((err)=>{toast.error("Something went Wrong")})
    return response 
})

const contactSlice = createSlice({
    name:"contactSlice",
    initialState,
    reducers:{},
    extraReducers:{
        [addTaskk_user.fulfilled]:(state,action)=>{
            console.log(action);
            

        },
        [addTaskk_user.rejected]:(state,_)=>{
            state.contact = [];
            
        },
        [addTaskk_user.pending]:(state,_)=>{
            state.contact = [];
            
        },
        [getTask_user.fulfilled]:(state,action)=>{
            state.contact = action.payload.data;
        },
        [getTask_user.rjected]:(state,_)=>{
            state.task = [];
        },
        [getTask_user.pending]:(state,_)=>{
            state.task = [];
        },
        

    }
})

export const {} = contactSlice.actions;

export default contactSlice.reducer;