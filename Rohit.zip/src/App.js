

// import { Provider } from 'react-redux';
import './App.css';
import Align from './myComponents/align';
// import { store } from './store/Store';




function App() {
  return (



    <div className="App">

          
    <Align/>
    </div>
    

    
  );
}

export default App;
